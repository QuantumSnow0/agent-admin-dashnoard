# WAM Live-Hook Preflight — Install / Verify / Rollback (OpenClaw 2026.7.1-2)

**Plugin id:** `wam-live-hook-preflight`  
**Version:** 0.1.0  
**Scope:** read-only presence probes on `message_received`, `before_prompt_build`, `before_tool_call`  
**Non-goals:** no attachment capture, no MCP bridge, no tools, no database access  

Production must not be enabled without separate explicit approval. This procedure is for a guarded Gateway only.

---

## PASS criteria (strict)

After one inbound turn that fires all three hooks (with a qualifying CSV/XLSX media message for `file_unique_id`):

Every field below must be **scalar-present** (non-empty string **or** finite number — not boolean/object) on **each** of the three hooks:

- `update_id`
- `file_unique_id`
- `runId`
- `messageId`
- `sessionKey`
- `accountId`
- `peerId`
- `senderId`

If any field is absent on any hook → **NO-GO**.  
Documenting absence is **not** a PASS.

Log lines must contain field **names** only (never values, paths, filenames, IDs, or message text).

---

## 1. Preconditions

```bash
openclaw --version
# expect: 2026.7.1-2
```

Build the plugin package locally (or extract the review archive):

```bash
cd admin-dashboard/tools/wam-openclaw-live-hook-preflight
npm ci
npm test
npm run build
npm pack
# produces: wam-openclaw-live-hook-preflight-0.1.0.tgz
```

Verify the pack against the external checksum:

```bash
sha256sum -c docs/wam-openclaw-live-hook-preflight-0.1.0.tgz.sha256
# Windows PowerShell:
# (Get-FileHash .\wam-openclaw-live-hook-preflight-0.1.0.tgz -Algorithm SHA256).Hash
```

---

## 2. Persistent environment (required)

On the Gateway host (systemd `Environment=` / `EnvironmentFile=` — must survive reboot):

```bash
# Required: OpenClaw version guard (missing → refuse)
OPENCLAW_VERSION=2026.7.1-2

# Required: explicit operator enablement (missing/0 → refuse registration)
WAM_LIVE_HOOK_PREFLIGHT_ENABLED=1
```

Unset `WAM_LIVE_HOOK_PREFLIGHT_ENABLED` (or set `0`) to keep the plugin installed but inert.

---

## 3. Install

```bash
cd admin-dashboard/tools/wam-openclaw-live-hook-preflight
openclaw plugins install npm-pack:./wam-openclaw-live-hook-preflight-0.1.0.tgz --force
openclaw plugins inspect wam-live-hook-preflight --runtime --json
```

Restart the Gateway so env + plugin load:

```bash
# example — use your real unit name
sudo systemctl restart openclaw-gateway
# or: openclaw gateway restart
```

---

## 4. Activation verification

```bash
openclaw plugins inspect wam-live-hook-preflight --runtime --json
```

Expect the plugin listed and loaded. Gateway logs on startup must include either:

- `[wam-live-hook-preflight] active (read-only) openclaw=2026.7.1-2` — enabled, or
- `[wam-live-hook-preflight] refused: set WAM_LIVE_HOOK_PREFLIGHT_ENABLED=1...` — installed but not enabled, or
- `[wam-live-hook-preflight] refused: openclaw_version_...` — fail closed

Confirm **no** tools were registered for this plugin (`contracts.tools` is empty).

---

## 5. Live presence check + log inspection

1. Send **one synthetic** CSV/XLSX (no real customer data) that triggers an agent turn with at least one tool call (so all three hooks fire).
2. Inspect Gateway logs:

```bash
# example
journalctl -u openclaw-gateway -n 200 --no-pager | grep wam-live-hook-preflight
# or your Gateway log path
```

Expected line shape:

```
[wam-live-hook-preflight] hook=message_received present_fields=update_id,file_unique_id,runId,... absent_fields=(none)
[wam-live-hook-preflight] verdict=PASS reason=all_capture_identity_fields_scalar_present_on_all_hooks
```

**Fail** the procedure if any log line contains paths, filenames, numeric/string ID values, or message text.

---

## 6. Disable (keep installed)

```bash
# In Gateway EnvironmentFile:
WAM_LIVE_HOOK_PREFLIGHT_ENABLED=0
# then restart Gateway
sudo systemctl restart openclaw-gateway
```

Plugin remains installed but `tryRegisterPreflightPlugin` refuses hooks.

---

## 7. Uninstall + rollback

```bash
openclaw plugins uninstall wam-live-hook-preflight
# remove env keys
# unset WAM_LIVE_HOOK_PREFLIGHT_ENABLED
# (keep or remove OPENCLAW_VERSION per other plugins)
sudo systemctl restart openclaw-gateway
openclaw plugins inspect wam-live-hook-preflight --runtime --json
# expect: not found / not loaded
```

---

## 8. Explicit non-goals

- Does not install or enable `wam-attachment-adapter`
- Does not call MCP / Agent Hub
- Does not mint capabilities or touch document paths
- Does not authorize production attachment adapter deploy
