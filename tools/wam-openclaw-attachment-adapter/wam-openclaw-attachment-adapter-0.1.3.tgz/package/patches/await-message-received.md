# Optional OpenClaw 2026.7.1-2 source change: await message_received

## Why

`message_received` is `fireAndForgetHook`. Adapter v0.1.3 records
`instructionObserved` inside that handler; `before_prompt_build` will not claim
until the flag is set (fail closed if the prompt races ahead).

Awaiting `message_received` before admitting the next inbound improves observe
completion latency; it is **not** required for correct fail-closed claim gating.

## Minimal change

Replace `fireAndForgetHook(hookRunner.runMessageReceived(...))` with an awaited
`runMessageReceived(...)` before agent admission. Rebuild from source.

## Classification

- Plugin-only claim gating via `instructionObserved`: LOCAL GO for v0.1.3 design.
- Capture/observe-before-next-inbound completeness: improved by this optional patch.
