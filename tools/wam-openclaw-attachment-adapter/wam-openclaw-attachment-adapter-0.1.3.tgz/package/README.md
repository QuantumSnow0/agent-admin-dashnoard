# WAM OpenClaw Attachment Adapter — Install & Rollback Runbook

**Adapter:** `wam-openclaw-attachment-adapter` **v0.1.3**  
**OpenClaw version guard:** **2026.7.1-2**  
**MCP:** **v0.1.18+** (host injects paths; model never sees raw document tools)  
**Handshake:** file `message_received` → pending; next `message_received` → `instructionObserved`; instruction `before_prompt_build` → claim  
**This runbook must not be executed against production without explicit approval.**

**v0.1.2 is production NO-GO** (used unavailable `before_prompt_build.messageId`).

---

## Migration / change matrix

| Component | This pass |
|---|---|
| MCP v0.1.18 runtime | **UNCHANGED** |
| Phase 1A.8 SQL migrations | **UNCHANGED** |
| JSONB / reconcile / SMS | **UNCHANGED** |
| OpenClaw core | **UNCHANGED** |
| Attachment adapter | **0.1.2 → 0.1.3** |
| Live-hook preflight | **0.1.1 → 0.1.2** |

---

## Live hook shapes

| Hook | Present | Absent |
|---|---|---|
| `message_received` | messageId, sessionKey, accountId, peerId, senderId | runId |
| `before_prompt_build` / `before_tool_call` | runId, sessionKey, peerId | messageId, accountId, senderId |

---

## 1. Preconditions

```bash
openclaw --version   # expect 2026.7.1-2
cd admin-dashboard/tools/wam-openclaw-attachment-adapter
npm ci && npm test && npm run build
```

---

## 2. Persistent environment

```bash
OPENCLAW_VERSION=2026.7.1-2
WAM_ATTACHMENT_MCP_ENTRY=/absolute/path/to/wam-apps-ai-mcp/dist/index.js
WAM_ATTACHMENT_ROOTS="/home/bonface/.openclaw/media/inbound:/home/bonface/.openclaw/workspaces/bonface-owner/media/inbound"
```

Never set `WAM_ATTACHMENT_ALLOW_MOCK_BRIDGE` on a real Gateway.

---

## 3. Operator flow

1. CSV/XLSX `message_received` → **pending**
2. File `before_prompt_build` → wait/ack; **no wrappers**
3. Next text `message_received` → **instructionObserved** (full identity)
4. Instruction `before_prompt_build` → **claim** + wrappers for that `runId`
5. Prompt racing ahead of instruction `message_received` → fail closed

---

## 4. Installation (when authorized)

```bash
npm pack
openclaw plugins install npm-pack:./wam-openclaw-attachment-adapter-0.1.3.tgz --force
sudo systemctl restart openclaw-gateway
```

---

## 5. Restart / rollback

Process-local store; restart clears state. Rollback: uninstall plugin; do not install v0.1.2.

Live-hook preflight: `wam-openclaw-live-hook-preflight@0.1.2` (preserves qualifying file snapshot).
