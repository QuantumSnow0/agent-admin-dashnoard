import fs from "node:fs";
import os from "node:os";
import path from "node:path";

/**
 * Isolated Telegram ingress fixture — synthetic only, no real customer data.
 * Simulates trusted fields available after download + staging.
 */
export type TelegramIngressFixture = {
  update_id: number;
  message_id: number;
  account: string;
  peer: string;
  sender: string;
  document: {
    file_id: string;
    file_unique_id: string;
    mime_type: string;
    file_name: string;
  };
  downloadedPath: string;
  sessionKey: string;
  runId: string;
};

export function createTelegramIngressFixture(opts?: {
  fileName?: string;
  contents?: string;
  sessionKey?: string;
}): {
  fixture: TelegramIngressFixture;
  cleanup: () => void;
  /** message_received event BEFORE staging completes */
  pendingEvent: Record<string, unknown>;
  /** message_received event AFTER local staging */
  stagedEvent: Record<string, unknown>;
  /** Follow-up text-only message (no attachment) */
  nextTextEvent: Record<string, unknown>;
} {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "wam-tg-ingress-"));
  const fileName = opts?.fileName ?? "synthetic-customers.csv";
  const downloadedPath = path.join(dir, fileName);
  const contents =
    opts?.contents ?? "Customer Name,Airtel Phone,Installed\nSynthetic A,254711890001,installed\n";
  fs.writeFileSync(downloadedPath, contents);

  const sessionKey = opts?.sessionKey ?? "agent:bonface-owner:telegram:peer-1001";
  const fixture: TelegramIngressFixture = {
    update_id: 900001,
    message_id: 42,
    account: "bonface-telegram",
    peer: "1001",
    sender: "1001",
    document: {
      file_id: "BQACAg-synthetic-file-id",
      file_unique_id: "AQADsyntheticUnique01",
      mime_type: "text/csv",
      file_name: fileName,
    },
    downloadedPath,
    sessionKey,
    runId: "run-fixture-001",
  };

  const pendingEvent = {
    mediaStagingPending: true,
    messageId: String(fixture.message_id),
    sessionKey: fixture.sessionKey,
    runId: fixture.runId,
    senderId: fixture.sender,
    accountId: fixture.account,
    peerId: fixture.peer,
    update_id: fixture.update_id,
    originalMedia: [
      {
        url: `telegram://file/${fixture.document.file_id}`,
        contentType: fixture.document.mime_type,
        file_unique_id: fixture.document.file_unique_id,
      },
    ],
    metadata: {
      update_id: fixture.update_id,
      file_unique_id: fixture.document.file_unique_id,
    },
  };

  const stagedEvent = {
    mediaStagingPending: false,
    messageId: String(fixture.message_id),
    sessionKey: fixture.sessionKey,
    runId: fixture.runId,
    senderId: fixture.sender,
    accountId: fixture.account,
    peerId: fixture.peer,
    update_id: fixture.update_id,
    media: [
      {
        path: fixture.downloadedPath,
        contentType: fixture.document.mime_type,
        kind: "document",
        file_unique_id: fixture.document.file_unique_id,
        messageId: String(fixture.message_id),
      },
    ],
    metadata: {
      update_id: fixture.update_id,
      file_unique_id: fixture.document.file_unique_id,
      account: fixture.account,
      peer: fixture.peer,
      sender: fixture.sender,
    },
    providerUpdate: {
      update_id: fixture.update_id,
    },
  };

  const nextTextEvent = {
    mediaStagingPending: false,
    messageId: "43",
    sessionKey: fixture.sessionKey,
    runId: "run-fixture-002",
    senderId: fixture.sender,
    accountId: fixture.account,
    peerId: fixture.peer,
    update_id: 900002,
    media: [],
    metadata: { update_id: 900002 },
  };

  return {
    fixture,
    cleanup: () => fs.rmSync(dir, { recursive: true, force: true }),
    pendingEvent,
    stagedEvent,
    nextTextEvent,
  };
}
