# Optional OpenClaw 2026.7.1-2 source change: await message_received

## Why

Installed OpenClaw `2026.7.1-2` dispatches plugin `message_received` with
`fireAndForgetHook(...)` (see `dist/dispatch-*.js`). That means capture can
complete after `before_prompt_build` for the **same** inbound turn (late capture).

v0.1.1 closes the **stale previous-capability** race with trusted `runId`
comparison on `before_prompt_build` / `before_tool_call` without a core patch.

Awaiting `message_received` is **recommended** so same-turn attachment capture
is visible before prompt/tools, but is **not** classified as mandatory for the
stale-capability defect when `runId` is populated on agent/tool context.

## Minimal change (operators applying from OpenClaw source)

In the inbound dispatch path that currently does:

```js
fireAndForgetHook(hookRunner.runMessageReceived(...), "...");
```

replace with an awaited call **before** agent run admission for that inbound
message (preserve error isolation / logging):

```js
await hookRunner.runMessageReceived(
  toPluginMessageReceivedEvent(messageReceivedHookContext),
  toPluginMessageContext(messageReceivedHookContext),
);
```

Rebuild/reinstall OpenClaw from that source commit. Do not patch minified dist
as source of truth.

## Classification

- Plugin-only (with runId checks): LOCAL GO for stale-capability.
- Late-capture same-turn reliability: improved by this source adapter; optional.
