# WAM OpenClaw Attachment Adapter — Install & Rollback Runbook

**Adapter:** `wam-openclaw-attachment-adapter` **v0.1.1**  
**OpenClaw version guard:** **2026.7.1-2** (also accepts documented 2026.7.1 / 2026.7.1-1 / 2026.7.2)  
**MCP:** **v0.1.18+** (host injects paths; model never sees raw document tools)  
**This runbook must not be executed against production without explicit approval.**

---

## 1. Preconditions

1. OpenClaw gateway reports a guarded version:
   ```bash
   openclaw --version
   # expect 2026.7.1-2
   ```
2. MCP package **v0.1.18** built with `WAM_AI_ATTACHMENT_ROOTS` set for the MCP child process.
3. Adapter built locally:
   ```bash
   cd admin-dashboard/tools/wam-openclaw-attachment-adapter
   npm ci
   npm test
   npm run build
   ```

---

## 2. Persistent environment (required — fail closed if missing)

Configure on the **Gateway host** (systemd `Environment=` / `EnvironmentFile=`, or equivalent — must survive reboot):

```bash
# Required: version guard (missing → adapter refuses to register)
OPENCLAW_VERSION=2026.7.1-2

# Required: real stdio MCP entry (missing → registration refused; mock never used in production)
WAM_ATTACHMENT_MCP_ENTRY=/absolute/path/to/wam-apps-ai-mcp/dist/index.js

# Optional node binary for MCP child
# WAM_ATTACHMENT_MCP_NODE=/usr/bin/node
```

Also ensure the MCP child inherits DB + attachment roots (`DATABASE_URL`, `WAM_AI_ATTACHMENT_ROOTS`, identity mode, etc.).

**Never** set `WAM_ATTACHMENT_ALLOW_MOCK_BRIDGE` on a real Gateway.

---

## 3. Installation (when authorized)

### 3.1 Install plugin package

```bash
cd admin-dashboard/tools/wam-openclaw-attachment-adapter
npm pack
openclaw plugins install npm-pack:./wam-openclaw-attachment-adapter-0.1.1.tgz --force
openclaw plugins inspect wam-attachment-adapter --runtime --json
```

### 3.2 bonface-owner toolFilter

**Always deny** raw path tools. **Only** pathless wrappers are model-visible for documents:

```json5
{
  agents: {
    list: [{
      id: "bonface-owner",
      tools: {
        deny: [
          "wam.business.documents.inspect_business_document",
          "wam.business.documents.parse_document_customers",
          "wam.business.documents.reconcile_document_customers"
        ],
        allow: [
          "inspect_current_business_document",
          "parse_current_document_customers",
          "reconcile_current_document_customers"
          // …prior non-document allowlist entries…
        ]
      }
    }]
  }
}
```

Do **not** enable raw `wam.business.documents.*` for bonface-owner. The adapter also blocks them in `before_tool_call`.

### 3.3 Wrapper names (correct)

| Model-visible wrapper | Host injects into MCP |
| --- | --- |
| `inspect_current_business_document` | `inspect_business_document` |
| `parse_current_document_customers` | `parse_document_customers` |
| `reconcile_current_document_customers` | `reconcile_document_customers` |

Correct reconcile wrapper name: **`reconcile_current_document_customers`** (not `reconcile_current_business_document`).

### 3.4 Post-install proof (synthetic only)

1. Send a **synthetic** CSV/XLSX (no real customer data).
2. Call inspect → parse → `reconcile_current_document_customers` (pathless).
3. Send a follow-up text message → wrappers absent (runId mismatch / next-message invalidate).
4. `/new` → capability cleared.
5. Confirm raw `wam.business.documents.*` remain blocked.

---

## 4. Rollback

1. `openclaw plugins uninstall wam-attachment-adapter`
2. Keep raw document tools **denied** until a safe binding exists.
3. Restart Gateway.
4. If optional await-message_received source change was applied, revert that OpenClaw source commit and rebuild.

---

## 5. Stale-capability / hook ordering

OpenClaw 2026.7.1-2 fires `message_received` via `fireAndForgetHook`. v0.1.1 mitigates the **next-text-turn stale capability** race by binding and comparing trusted **runId** on `before_prompt_build` / `before_tool_call`.

Optional source note: `patches/await-message-received.md` (same-turn late-capture UX).

---

## 6. Upgrade

On any OpenClaw upgrade: re-run version guard; if outside allowed tags, adapter refuses load. Reinstall pack; re-run synthetic proof.
