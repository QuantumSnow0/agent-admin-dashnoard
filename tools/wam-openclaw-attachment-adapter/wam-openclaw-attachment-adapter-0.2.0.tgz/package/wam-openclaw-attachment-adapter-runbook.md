# WAM OpenClaw Attachment Adapter — Install & Rollback Runbook

**Adapter:** `wam-openclaw-attachment-adapter` **v0.2.0**
**OpenClaw:** stock **2026.7.1-2** (no core patch)
**MCP:** **v0.1.18+** (unchanged)

Plugin-only **sequence binding** is **ACCEPTED** for the private bonface-owner
Telegram session. See `patches/PLUGIN-ONLY-SEQUENCE-BINDING.md`.

---

## Trust model (explicitly weaker)

1. File `message_received` (CSV/XLSX under verified roots) → pending.
2. Immediately following text `message_received` (same agent/session/account/peer/sender) → `instruction_observed`.
3. Sole subsequent `before_prompt_build` claims with **sessionKey + peerId + runId**.
4. Stock OpenClaw does **not** expose `messageId` on `before_prompt_build`.
5. This is **sequence binding**, not cryptographic message-to-prompt binding.

### Residual risk

A delayed/out-of-order `before_prompt_build` after `instruction_observed` cannot
be proven to match the instruction message without `messageId`. Accept only for
this private single-user Telegram session with fail-closed invalidation.

---

## Migration

| Component | This pass |
|---|---|
| MCP v0.1.18 | **UNCHANGED** |
| Phase 1A.8 SQL / JSONB / reconcile / SMS | **UNCHANGED** |
| OpenClaw core | **UNCHANGED stock 2026.7.1-2** (no patch, no custom build) |
| Attachment adapter | **0.1.x → 0.2.0** (trust model change) |

Removed: `OPENCLAW_WAM_CORE_PATCH`, patched OpenClaw, messageId claim gate,
custom OpenClaw build packages.

---

## Environment

```bash
OPENCLAW_VERSION=2026.7.1-2
WAM_ATTACHMENT_MCP_ENTRY=/absolute/path/to/wam-apps-ai-mcp/dist/index.js
WAM_ATTACHMENT_ROOTS="/home/bonface/.openclaw/media/inbound:/home/bonface/.openclaw/workspaces/bonface-owner/media/inbound"
# Do NOT set OPENCLAW_WAM_CORE_PATCH
```

Verified roots only (no directory scanning / newest-file selection):

- `/home/bonface/.openclaw/media/inbound`
- `/home/bonface/.openclaw/workspaces/bonface-owner/media/inbound`

---

## Artifacts (review only — not deployed by this pass)

| Artifact | Role |
|---|---|
| `docs/wam-openclaw-attachment-adapter-0.2.0.tgz` | Adapter npm pack |
| `docs/wam-openclaw-attachment-adapter-0.2.0.tgz.sha256` | Sidecar |
| `docs/wam-openclaw-attachment-adapter-0.2.0-review-source.tar.gz` | Review source |
| `docs/wam-openclaw-attachment-adapter-0.2.0-review-source.tar.gz.sha256` | Sidecar |

---

## VPS facts

- OpenClaw: `/home/bonface/.npm-global`
- Gateway: systemd **user** service
  `/home/bonface/.config/systemd/user/openclaw-gateway.service`
- Use `systemctl --user`, `journalctl --user -u openclaw-gateway.service`
- `npm install -g` **without** sudo

---

## Install (when authorized)

```bash
ts=$(date +%Y%m%d-%H%M%S)
backup_dir=/home/bonface/wam-ai-validation/backups/$ts
mkdir -p "$backup_dir"

systemctl --user stop openclaw-gateway.service

# Optional: snapshot current plugin install state
openclaw plugins list > "$backup_dir/plugins-before.txt" || true
printf '%s\n' "$backup_dir" > "$backup_dir/BACKUP_DIR.txt"

# Ensure stock OpenClaw (no custom patched package)
npm install -g openclaw@2026.7.1-2

openclaw plugins install npm-pack:./wam-openclaw-attachment-adapter-0.2.0.tgz --force

# Env: set WAM_ATTACHMENT_ROOTS / MCP entry; unset OPENCLAW_WAM_CORE_PATCH
systemctl --user start openclaw-gateway.service
systemctl --user status openclaw-gateway.service
journalctl --user -u openclaw-gateway.service -n 50
```

Synthetic proof: file → instruction → one prompt → inspect (safe metadata) →
parse → reconcile → consumed. Delayed file-only prompt must not claim.

---

## Rollback

```bash
backup_dir=$(cat /home/bonface/wam-ai-validation/backups/<ts>/BACKUP_DIR.txt)
# or set explicitly

systemctl --user stop openclaw-gateway.service
openclaw plugins uninstall wam-attachment-adapter || true
# Prior adapter version may be reinstalled from its reviewed .tgz if desired
systemctl --user start openclaw-gateway.service
journalctl --user -u openclaw-gateway.service -n 30
```

---

## Restart behavior

Process-local capability store; restart clears pending/claimed (fail closed).
TTL maximum 120 seconds.
