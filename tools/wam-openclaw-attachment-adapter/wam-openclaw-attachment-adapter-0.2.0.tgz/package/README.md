# wam-openclaw-attachment-adapter

**Version:** 0.2.0  
**OpenClaw:** stock **2026.7.1-2** (no core patch)

Plugin-only **sequence binding** for the private `bonface-owner` Telegram session.
See `patches/PLUGIN-ONLY-SEQUENCE-BINDING.md` and `wam-openclaw-attachment-adapter-runbook.md`.

## Binding (weaker by design)

1. Qualifying CSV/XLSX `message_received` → one pending attachment (agent/session/account/peer/sender).
2. Immediately following text `message_received` from the same identity → `instruction_observed`.
3. Sole subsequent `before_prompt_build` claims with `sessionKey + peerId + runId`.
4. Not cryptographic message-to-prompt binding (stock OpenClaw does not expose `messageId` on BPB).

## Commands

```bash
npm ci
npm run typecheck
npm run build
npm test
```

## Packaging

Runtime: `npm pack` → `wam-openclaw-attachment-adapter-0.2.0.tgz`  
Do not set `OPENCLAW_WAM_CORE_PATCH`. Do not install patched OpenClaw.
