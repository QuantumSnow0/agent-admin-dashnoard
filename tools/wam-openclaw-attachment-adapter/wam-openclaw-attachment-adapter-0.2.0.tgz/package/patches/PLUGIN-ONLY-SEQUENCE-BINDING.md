# Plugin-only sequence binding (v0.2.0) — ACCEPTED

## Verdict

**ACCEPTED** for the private `bonface-owner` Telegram session on stock
OpenClaw **2026.7.1-2**. No OpenClaw core patch. No `OPENCLAW_WAM_CORE_PATCH`.
No custom OpenClaw build packages.

## Binding semantics (weaker by design)

1. Qualifying CSV/XLSX `message_received` stores one pending attachment for
   `agentId`, `sessionKey`, `accountId`, `peerId`, `senderId`.
2. The immediately following non-file `message_received` from the same identity
   marks `instruction_observed`.
3. The sole subsequent `before_prompt_build` may claim using
   `sessionKey + peerId + runId` (stock OpenClaw does not expose `messageId`
   there).
4. This is **sequence binding**, not cryptographic message-to-prompt binding.

## Residual risk (must remain documented)

Without `messageId` on `before_prompt_build`, a delayed or out-of-order prompt
after `instruction_observed` cannot be proven to correspond to the instruction
message. The private single-user Telegram session and fail-closed invalidation
rules (intervening text, new file, TTL 120s, `/new`, restart, fingerprint)
reduce but do not eliminate that risk.

## Fail closed

Mismatch of account/peer/sender/agent/session; second intervening text;
replacement file; `/new`/reset; TTL ≤ 120s; gateway restart; file
delete/replace/fingerprint mismatch; missing identity; unsupported format;
symlink/traversal/outside the two verified roots; duplicate staged fingerprint
across sessions; raw path-taking document tools.
