# Optional OpenClaw 2026.7.1-2 source change: await message_received

## Why

Installed OpenClaw `2026.7.1-2` dispatches plugin `message_received` with
`fireAndForgetHook(...)` (see `dist/dispatch-*.js`). Capture can therefore
complete after a later inbound begins.

## Adapter v0.1.2 plugin-only posture

- **Claim-before-tools:** LOCAL GO. Claim runs synchronously inside
  `before_prompt_build` / `before_tool_call` where live OpenClaw provides
  `runId`. Wrappers gate on `instructionRunId === turn.runId`.
- **File capture completion before next inbound:** residual risk. If the next
  instruction arrives while file `message_received` is still in-flight, claim
  fails closed (no pending). This optional await improves capture completion
  reliability; it is **not** required for claim-before-tools ordering.

## Minimal change (operators applying from OpenClaw source)

In the inbound dispatch path that currently does:

```js
fireAndForgetHook(hookRunner.runMessageReceived(...), "...");
```

replace with an awaited call **before** admitting the next inbound message
(preserve error isolation / logging):

```js
await hookRunner.runMessageReceived(
  toPluginMessageReceivedEvent(messageReceivedHookContext),
  toPluginMessageContext(messageReceivedHookContext),
);
```

Rebuild/reinstall OpenClaw from that source commit. Do not patch minified dist
as source of truth.

## Classification

- Plugin-only claim-before-tools: **LOCAL GO** for adapter v0.1.2.
- Capture-before-next-inbound completeness: improved by this source change
  (recommended, not mandatory for LOCAL GO).
