# WAM OpenClaw Attachment Adapter — Install & Rollback Runbook

**Adapter:** `wam-openclaw-attachment-adapter` **v0.1.2**  
**OpenClaw version guard:** **2026.7.1-2**  
**MCP:** **v0.1.18+** (host injects paths; model never sees raw document tools)  
**Handshake:** file message → pending; immediate next instruction → claim + wrappers  
**This runbook must not be executed against production without explicit approval.**

---

## Migration / change matrix

| Component | This pass |
|---|---|
| MCP v0.1.18 runtime | **UNCHANGED** |
| Phase 1A.8 SQL migrations | **UNCHANGED** |
| JSONB transport | **UNCHANGED** |
| Customer reconciliation / SMS | **UNCHANGED** |
| OpenClaw core | **UNCHANGED** (optional await patch only) |
| Attachment adapter | **0.1.1 → 0.1.2** |

---

## 1. Preconditions

```bash
openclaw --version   # expect 2026.7.1-2
cd admin-dashboard/tools/wam-openclaw-attachment-adapter
npm ci && npm test && npm run build
```

---

## 2. Persistent environment

```bash
OPENCLAW_VERSION=2026.7.1-2
WAM_ATTACHMENT_MCP_ENTRY=/absolute/path/to/wam-apps-ai-mcp/dist/index.js
WAM_ATTACHMENT_ROOTS="/home/bonface/.openclaw/media/inbound:/home/bonface/.openclaw/workspaces/bonface-owner/media/inbound"
```

Never set `WAM_ATTACHMENT_ALLOW_MOCK_BRIDGE` on a real Gateway.

---

## 3. Operator flow (Telegram)

1. User sends CSV/XLSX → **pending** (120s). Model acks and waits; no wrappers.
2. Immediate next text instruction → **claim** with that turn’s `runId`; wrappers for that run only.
3. Intervening message, identity mismatch, `/new`, expiry, or third message → invalidate.

---

## 4. Installation (when authorized)

```bash
npm pack
openclaw plugins install npm-pack:./wam-openclaw-attachment-adapter-0.1.2.tgz --force
# deny raw document tools; allow pathless wrappers (same allowlist as v0.1.1)
sudo systemctl restart openclaw-gateway
```

Wrapper names: `inspect_current_business_document`, `parse_current_document_customers`, `reconcile_current_document_customers`.

---

## 5. Restart behavior

Capability state is **process-local**. Gateway restart clears pending/claimed (fail closed). Re-send file, then instruction.

---

## 6. Rollback

```bash
openclaw plugins uninstall wam-attachment-adapter
sudo systemctl restart openclaw-gateway
```

---

## 7. Hook ordering

`message_received` is `fireAndForgetHook`. Claim is sync in `before_prompt_build` / `before_tool_call`. See `patches/await-message-received.md` and `src/openclaw-hook-proof.ts`.

Live-hook preflight (two-message PASS): package **`wam-openclaw-live-hook-preflight@0.1.1`**.
