import fs from "node:fs";
import os from "node:os";
import path from "node:path";

/**
 * Isolated Telegram ingress fixture — synthetic only.
 * Reflects live OpenClaw 2026.7.1-2: message_received lacks runId/update_id/file_unique_id.
 */
export type TelegramIngressFixture = {
  message_id: number;
  account: string;
  peer: string;
  sender: string;
  document: {
    mime_type: string;
    file_name: string;
  };
  downloadedPath: string;
  rootDir: string;
  sessionKey: string;
  /** Instruction-turn run id (available on before_prompt_build, not message_received). */
  instructionRunId: string;
};

export function createTelegramIngressFixture(opts?: {
  fileName?: string;
  contents?: string;
  sessionKey?: string;
}): {
  fixture: TelegramIngressFixture;
  cleanup: () => void;
  pendingEvent: Record<string, unknown>;
  stagedEvent: Record<string, unknown>;
  nextTextEvent: Record<string, unknown>;
  /** before_prompt_build ctx for the file turn (has runId; same messageId as file). */
  fileTurnCtx: Record<string, unknown>;
  /** before_prompt_build ctx for the instruction turn. */
  instructionTurnCtx: Record<string, unknown>;
} {
  const rootDir = fs.mkdtempSync(path.join(os.tmpdir(), "wam-tg-root-"));
  const inbound = path.join(rootDir, "inbound");
  fs.mkdirSync(inbound);
  const fileName = opts?.fileName ?? "synthetic-customers.csv";
  const downloadedPath = path.join(inbound, fileName);
  const contents =
    opts?.contents ??
    "Customer Name,Airtel Phone,Installed\nSynthetic A,254711890001,installed\n";
  fs.writeFileSync(downloadedPath, contents);

  const sessionKey = opts?.sessionKey ?? "agent:bonface-owner:telegram:peer-1001";
  const fixture: TelegramIngressFixture = {
    message_id: 42,
    account: "bonface-telegram",
    peer: "1001",
    sender: "1001",
    document: {
      mime_type: "text/csv",
      file_name: fileName,
    },
    downloadedPath,
    rootDir,
    sessionKey,
    instructionRunId: "run-instruction-002",
  };

  const pendingEvent = {
    mediaStagingPending: true,
    messageId: String(fixture.message_id),
    sessionKey: fixture.sessionKey,
    senderId: fixture.sender,
    accountId: fixture.account,
    peerId: fixture.peer,
  };

  // Live message_received: no runId / update_id / file_unique_id required
  const stagedEvent = {
    mediaStagingPending: false,
    messageId: String(fixture.message_id),
    sessionKey: fixture.sessionKey,
    senderId: fixture.sender,
    accountId: fixture.account,
    peerId: fixture.peer,
    media: [
      {
        path: fixture.downloadedPath,
        contentType: fixture.document.mime_type,
        kind: "document",
        messageId: String(fixture.message_id),
      },
    ],
  };

  const nextTextEvent = {
    mediaStagingPending: false,
    messageId: "43",
    sessionKey: fixture.sessionKey,
    senderId: fixture.sender,
    accountId: fixture.account,
    peerId: fixture.peer,
    media: [],
  };

  const fileTurnCtx = {
    sessionKey: fixture.sessionKey,
    runId: "run-file-001",
    messageId: String(fixture.message_id),
    accountId: fixture.account,
    chatId: fixture.peer,
    senderId: fixture.sender,
  };

  const instructionTurnCtx = {
    sessionKey: fixture.sessionKey,
    runId: fixture.instructionRunId,
    messageId: "43",
    accountId: fixture.account,
    chatId: fixture.peer,
    senderId: fixture.sender,
  };

  return {
    fixture,
    cleanup: () => fs.rmSync(rootDir, { recursive: true, force: true }),
    pendingEvent,
    stagedEvent,
    nextTextEvent,
    fileTurnCtx,
    instructionTurnCtx,
  };
}
