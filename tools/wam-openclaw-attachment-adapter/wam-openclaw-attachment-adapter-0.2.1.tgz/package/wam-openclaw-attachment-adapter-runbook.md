# WAM OpenClaw Attachment Adapter — Install & Rollback Runbook

**Adapter:** `wam-openclaw-attachment-adapter` **v0.2.1**
**OpenClaw:** stock **2026.7.1-2** (no core patch)
**MCP:** Phase 1A.8 **wam-apps-ai-mcp v0.1.18+** (required; enforced at registration)

Plugin-only **sequence binding** is **ACCEPTED** for the private bonface-owner
Telegram session. See `patches/PLUGIN-ONLY-SEQUENCE-BINDING.md`.

---

## Trust model (explicitly weaker)

1. File `message_received` (CSV/XLSX under verified roots) → pending.
2. Immediately following text `message_received` (same agent/session/account/peer/sender) → `instruction_observed`.
3. Sole subsequent `before_prompt_build` claims with **sessionKey + peerId + runId**.
4. Stock OpenClaw does **not** expose `messageId` on `before_prompt_build`.
5. This is **sequence binding**, not cryptographic message-to-prompt binding.
6. Content SHA-256 is pinned on first wrapper revalidation (outside `message_received`)
   and reserved process-locally so identical bytes cannot be parsed/reconciled twice
   across distinct inodes/paths.

### Residual risk

A delayed/out-of-order `before_prompt_build` after `instruction_observed` cannot
be proven to match the instruction message without `messageId`. Accept only for
this private single-user Telegram session with fail-closed invalidation.

---

## Prerequisites (must be done before adapter install)

1. **Phase 1A.8 MCP `wam-apps-ai-mcp` v0.1.18+** deployed.
2. Its SQL migrations / verifiers for reconcile completed and verified.
3. Adapter registration **fail-closes** unless `WAM_ATTACHMENT_MCP_ENTRY` resolves
   (via realpath containment) to a local `package.json` with
   `"name": "wam-apps-ai-mcp"` and version `>=0.1.18`. Env version strings are
   **not** trusted.

Do **not** install adapter v0.2.1 until MCP 0.1.18 + SQL verifiers are green.

---

## Migration

| Component | This pass |
|---|---|
| MCP v0.1.18 + Phase 1A.8 SQL | **REQUIRED prerequisite** (unchanged code; must already be live) |
| OpenClaw core | **UNCHANGED stock 2026.7.1-2** (no patch, no custom build) |
| Attachment adapter | **0.2.0 → 0.2.1** (tool policy, MCP gate, content-digest) |

Removed from runtime package: core-patch materials, `PLUGIN-ONLY-NO-GO.md`.
Do **not** set `OPENCLAW_WAM_CORE_PATCH`.

---

## Environment

```bash
OPENCLAW_VERSION=2026.7.1-2
WAM_ATTACHMENT_MCP_ENTRY=/absolute/path/to/wam-apps-ai-mcp/dist/index.js
WAM_ATTACHMENT_ROOTS="/home/bonface/.openclaw/media/inbound:/home/bonface/.openclaw/workspaces/bonface-owner/media/inbound"
# Do NOT set OPENCLAW_WAM_CORE_PATCH
```

Verified roots only (no directory scanning / newest-file selection):

- `/home/bonface/.openclaw/media/inbound`
- `/home/bonface/.openclaw/workspaces/bonface-owner/media/inbound`

---

## openclaw.json — tools.alsoAllow (required)

Wrappers register with `optional: true`. With `tools.profile: "coding"` they are
**not** exposed unless listed in `tools.alsoAllow`. Preserve the existing profile;
do **not** switch to `full` and do **not** replace other alsoAllow entries.

Config path: `/home/bonface/.openclaw/openclaw.json`

### Idempotent Node edit (preserve profile + merge alsoAllow + plugins.allow)

```bash
node <<'EOF'
const fs = require("fs");
const path = "/home/bonface/.openclaw/openclaw.json";
const cfg = JSON.parse(fs.readFileSync(path, "utf8"));

const WRAPPERS = [
  "inspect_current_business_document",
  "parse_current_document_customers",
  "reconcile_current_document_customers",
];
const PLUGIN_ID = "wam-attachment-adapter";

cfg.tools = cfg.tools && typeof cfg.tools === "object" ? cfg.tools : {};
// Preserve existing profile (expected: "coding"). Do not overwrite if set.
if (typeof cfg.tools.profile !== "string" || !cfg.tools.profile.trim()) {
  cfg.tools.profile = "coding";
}
const also = Array.isArray(cfg.tools.alsoAllow) ? cfg.tools.alsoAllow.slice() : [];
for (const t of WRAPPERS) {
  if (!also.includes(t)) also.push(t);
}
cfg.tools.alsoAllow = also;

cfg.plugins = cfg.plugins && typeof cfg.plugins === "object" ? cfg.plugins : {};
const allow = Array.isArray(cfg.plugins.allow) ? cfg.plugins.allow.slice() : [];
if (!allow.includes(PLUGIN_ID)) allow.push(PLUGIN_ID);
cfg.plugins.allow = allow;

fs.writeFileSync(path, JSON.stringify(cfg, null, 2) + "\n");
console.log("tools.profile=", cfg.tools.profile);
console.log("tools.alsoAllow=", cfg.tools.alsoAllow);
console.log("plugins.allow=", cfg.plugins.allow);
EOF
```

**plugins.allow:** append `wam-attachment-adapter` only. Preserve every currently
trusted plugin ID. Never replace the array with a singleton.

### Expected shape (illustrative)

```json
{
  "tools": {
    "profile": "coding",
    "alsoAllow": [
      "inspect_current_business_document",
      "parse_current_document_customers",
      "reconcile_current_document_customers"
    ]
  },
  "plugins": {
    "allow": ["…existing trusted ids…", "wam-attachment-adapter"]
  }
}
```

### Raw MCP document tools stay hidden

- Path-taking `wam.business.documents.*` tools remain blocked by the adapter
  `before_tool_call` hook.
- They must **not** be added to `tools.alsoAllow`.
- Only the three pathless `*_current_*` wrappers above are allowlisted.

---

## Artifacts (review only — not deployed by this pass)

| Artifact | Role |
|---|---|
| `docs/wam-openclaw-attachment-adapter-0.2.1.tgz` | Adapter npm pack |
| `docs/wam-openclaw-attachment-adapter-0.2.1.tgz.sha256` | Sidecar |
| `docs/wam-openclaw-attachment-adapter-0.2.1-review-source.tar.gz` | Review source |
| `docs/wam-openclaw-attachment-adapter-0.2.1-review-source.tar.gz.sha256` | Sidecar |

---

## VPS facts

- OpenClaw: `/home/bonface/.npm-global`
- Gateway: systemd **user** service
  `/home/bonface/.config/systemd/user/openclaw-gateway.service`
- Use `systemctl --user`, `journalctl --user -u openclaw-gateway.service`
- `npm install -g` **without** sudo

---

## Install (when authorized)

```bash
ts=$(date +%Y%m%d-%H%M%S)
backup_dir=/home/bonface/wam-ai-validation/backups/$ts
mkdir -p "$backup_dir"

# Confirm MCP prerequisite first
# (package name wam-apps-ai-mcp, version >=0.1.18, SQL verifiers green)

systemctl --user stop openclaw-gateway.service

cp -a /home/bonface/.openclaw/openclaw.json "$backup_dir/openclaw.json.bak" || true
openclaw plugins list > "$backup_dir/plugins-before.txt" || true
printf '%s\n' "$backup_dir" > "$backup_dir/BACKUP_DIR.txt"

# Ensure stock OpenClaw (no custom patched package)
npm install -g openclaw@2026.7.1-2

# Apply tools.alsoAllow + plugins.allow merge (script above)
# then:
openclaw plugins install npm-pack:./wam-openclaw-attachment-adapter-0.2.1.tgz --force

# Env: WAM_ATTACHMENT_ROOTS + WAM_ATTACHMENT_MCP_ENTRY; unset OPENCLAW_WAM_CORE_PATCH
systemctl --user start openclaw-gateway.service
systemctl --user status openclaw-gateway.service
journalctl --user -u openclaw-gateway.service -n 50
```

Synthetic proof: file → instruction → one prompt → inspect (safe metadata) →
parse → reconcile → consumed. Delayed file-only prompt must not claim.
Identical bytes under both inbound roots must process at most once.

---

## Rollback

```bash
backup_dir=$(cat /home/bonface/wam-ai-validation/backups/<ts>/BACKUP_DIR.txt)

systemctl --user stop openclaw-gateway.service
openclaw plugins uninstall wam-attachment-adapter || true
# Restore openclaw.json from backup if policy edits must be reverted:
# cp -a "$backup_dir/openclaw.json.bak" /home/bonface/.openclaw/openclaw.json
systemctl --user start openclaw-gateway.service
journalctl --user -u openclaw-gateway.service -n 30
```

---

## Restart behavior

Process-local capability store (including content-digest reservations); restart
clears pending/claimed/fingerprint state (fail closed). TTL maximum 120 seconds.
