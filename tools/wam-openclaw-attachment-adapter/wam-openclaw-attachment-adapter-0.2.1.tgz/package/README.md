# wam-openclaw-attachment-adapter

**Version:** 0.2.1  
**OpenClaw:** stock **2026.7.1-2** (no core patch)  
**MCP:** `wam-apps-ai-mcp` **>=0.1.18** (enforced via local package.json + realpath)

Plugin-only **sequence binding** for the private `bonface-owner` Telegram session.
See `patches/PLUGIN-ONLY-SEQUENCE-BINDING.md` and `wam-openclaw-attachment-adapter-runbook.md`.

## Binding (weaker by design)

1. Qualifying CSV/XLSX `message_received` → one pending attachment.
2. Immediately following text `message_received` from the same identity → `instruction_observed`.
3. Sole subsequent `before_prompt_build` claims with `sessionKey + peerId + runId`.
4. Not cryptographic message-to-prompt binding.
5. Content SHA-256 reserved on first wrapper revalidation (cross-inode duplicate fail-closed).

## Commands

```bash
npm ci --ignore-scripts
npm run typecheck
npm run build
npm test
```

## Packaging

Runtime: `npm pack` → `wam-openclaw-attachment-adapter-0.2.1.tgz`  
Configure `tools.alsoAllow` for the three pathless wrappers; keep `tools.profile="coding"`.  
Do not set `OPENCLAW_WAM_CORE_PATCH`. Do not install patched OpenClaw.
