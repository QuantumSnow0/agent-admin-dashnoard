# OpenClaw 2026.7.1-2 — WAM inbound identity + await message_received

**Patch id:** `inbound-identity-await-mr-2026.7.1-2`  
**Applies to:** OpenClaw **exactly** `2026.7.1-2` (git tag / npm version)  
**Do not** patch minified `dist/` as source of truth. Apply to **TypeScript source**, rebuild, reinstall Gateway.

## Why (plugin-only NO-GO)

See `../PLUGIN-ONLY-NO-GO.md`. Live VPS sees file MR → instruction MR → **one**
`before_prompt_build` without `messageId`. Plugin cannot safely claim.

## Changes (narrow)

### A. Await `message_received` before continuing inbound dispatch

**File:** `src/auto-reply/reply/dispatch-from-config.ts`

Replace fire-and-forget plugin `message_received` with awaited call (preserve
error isolation). Internal hooks may remain fire-and-forget.

```ts
// BEFORE
fireAndForgetHook(
  hookRunner.runMessageReceived(
    toPluginMessageReceivedEvent(messageReceivedHookContext),
    toPluginMessageContext(messageReceivedHookContext),
  ),
  "dispatch-from-config: message_received plugin hook failed",
);

// AFTER
try {
  await hookRunner.runMessageReceived(
    toPluginMessageReceivedEvent(messageReceivedHookContext),
    toPluginMessageContext(messageReceivedHookContext),
  );
} catch (err) {
  // keep prior logging semantics
  console.warn(
    "dispatch-from-config: message_received plugin hook failed",
    err,
  );
}
```

Make `emitMessageReceivedHooks` `async` and `await` it at both call sites
(~fast-abort path and main path). Do **not** admit agent/prompt work for that
inbound until the await completes.

### B. Propagate trusted inbound message identity into agent hooks

**Files:**

1. `src/plugins/hook-types.ts` — add to `PluginHookAgentContext`:
   ```ts
   messageId?: string;
   accountId?: string;
   ```
2. `src/plugins/hook-agent-context.ts` — extend
   `buildAgentHookContextIdentityFields` to accept and emit
   `messageId` / `accountId` (stringified via existing normalize helpers)
   when `trigger === "user"`.
3. `src/agents/harness/hook-context.ts` — add optional `messageId` /
   `accountId` on `AgentHarnessHookContext` and pass into identity fields.
4. Call sites that build agent hook context from an inbound turn
   (notably `src/auto-reply/reply/get-reply*.ts` / embedded agent runner) must
   pass:
   - `messageId` from `MessageSidFull ?? MessageSid ?? MessageSidFirst ?? MessageSidLast`
   - `accountId` from `AccountId` when present
   - existing `senderId` / `chatId` (peer)

Reference intent matches upstream direction in openclaw#124557 (messageId on
agent hook context); this patch is the **minimal 2026.7.1-2 backport** plus
await of `message_received`.

## Version / enablement guard (Gateway)

After rebuild/install:

```bash
OPENCLAW_VERSION=2026.7.1-2
OPENCLAW_WAM_CORE_PATCH=inbound-identity-await-mr-2026.7.1-2
```

Adapter v0.1.4 **refuses to register** unless both are set and the patch id
matches exactly.

## Apply

```bash
git clone https://github.com/openclaw/openclaw.git
cd openclaw
git checkout 2026.7.1-2   # or the commit that published npm 2026.7.1-2
# apply edits described above (or git apply files/*.patch when provided)
pnpm install && pnpm build
# install rebuilt package onto Gateway host; restart openclaw-gateway
```

Exact unified diffs for the two primary files are under `files/`.

## Rollback

1. Unset `OPENCLAW_WAM_CORE_PATCH` (adapter refuses load — fail closed).
2. Reinstall stock OpenClaw `2026.7.1-2` from npm (no WAM patch).
3. `sudo systemctl restart openclaw-gateway`
4. Optionally uninstall `wam-attachment-adapter`.

## Verification

1. Live-hook preflight: `before_prompt_build` must show `messageId` (+ ideally
   `accountId`/`senderId`) scalar-present.
2. Synthetic: file CSV → text instruction → **one** prompt → wrappers available.
3. Synthetic: delayed file prompt with file `messageId` must **not** claim.
