# Plugin-only feasibility: NO-GO (adapter ≥0.1.3 live shape)

## Observed live sequence (VPS preflight, OpenClaw 2026.7.1-2)

1. `message_received` (file) — has messageId / sessionKey / accountId / peerId / senderId; no runId
2. `message_received` (instruction) — same identity fields; no runId
3. **exactly one** `before_prompt_build` — has runId / sessionKey / peerId;
   **no** messageId / accountId / senderId

## Why plugin-only cannot securely claim

After step 2, `instructionObserved=true` and `lastFileWaitRunId=null`.
The sole `before_prompt_build` could be:

| Reality | Required action |
|---|---|
| Instruction turn (observed live) | **claim** |
| Delayed file turn (file agent admitted late) | **wait / do not claim** |

With only `runId` + `sessionKey` + `peerId`, these cases are **indistinguishable**.

Any plugin-only rule fails one of:

- Always claim first post-observe prompt → delayed file prompt steals the attachment (unsafe)
- Always treat first post-observe prompt as file wait → live single instruction prompt never claims (broken; v0.1.3 defect)
- Heuristics on timing / runId sets → not identity-bound; unsafe under concurrent sequences

`bindingUsableForTools` cannot recover: recording the current run as `lastFileWaitRunId` when null permanently blocks that instruction run.

## Threats that remain unsolved without inbound identity on prompt hooks

- Delayed file prompt after `instructionObserved`
- File + instruction `message_received` before one prompt (live)
- Prompt racing before instruction observation (fail-closed only; not recoverable without identity)
- Duplicate delivery / third / intervening messages (partially handled on `message_received`, not on ambiguous prompt)
- Two rapid file→instruction sequences in one session
- Cross peer/account/sender/session reuse on prompt (prompt lacks account/sender)

## Verdict

**Plugin-only: NO-GO.**

Required OpenClaw **source** changes (not minified dist):

1. Await `message_received` before agent/prompt admission for that inbound.
2. Propagate trusted inbound `messageId` (+ `accountId` / `senderId` when known) into agent hook context used by `before_prompt_build` / `before_tool_call`.

See `patches/openclaw-2026.7.1-2-wam-inbound-identity/`.
