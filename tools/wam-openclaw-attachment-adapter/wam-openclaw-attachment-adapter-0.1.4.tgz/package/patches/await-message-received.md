# Superseded for production — see required core patch

Stock OpenClaw `2026.7.1-2` plugin-only attachment binding is **NO-GO**.

Use the reviewed patch package:

`patches/openclaw-2026.7.1-2-wam-inbound-identity/`

Patch id: `inbound-identity-await-mr-2026.7.1-2`

That package includes:

1. Await `message_received` before prompt admission
2. Propagate trusted inbound `messageId` (+ accountId/senderId) into agent hooks

Do **not** patch minified dist. Apply to TypeScript source, rebuild, set
`OPENCLAW_WAM_CORE_PATCH=inbound-identity-await-mr-2026.7.1-2`.

See also `PLUGIN-ONLY-NO-GO.md`.
