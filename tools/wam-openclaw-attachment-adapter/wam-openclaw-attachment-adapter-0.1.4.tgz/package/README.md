# WAM OpenClaw Attachment Adapter — Install & Rollback Runbook

**Adapter:** `wam-openclaw-attachment-adapter` **v0.1.4**  
**OpenClaw:** **2026.7.1-2** + core patch `inbound-identity-await-mr-2026.7.1-2`  
**MCP:** **v0.1.18+** (unchanged)  

**Plugin-only on stock OpenClaw: NO-GO.** Do not deploy v0.1.2 / v0.1.3 / v0.1.4 without the core patch.

---

## Migration / change matrix

| Component | This pass |
|---|---|
| MCP v0.1.18 | **UNCHANGED** |
| Phase 1A.8 SQL / JSONB / reconcile / SMS | **UNCHANGED** |
| OpenClaw core | **REQUIRED source patch** (not dist) |
| Attachment adapter | **0.1.3 → 0.1.4** |

---

## Why core patch is required

Live sequence: file `message_received` → instruction `message_received` → **one** `before_prompt_build` without `messageId`. Plugin cannot tell a delayed file prompt from the instruction prompt. Proof: `patches/PLUGIN-ONLY-NO-GO.md`.

Patch: `patches/openclaw-2026.7.1-2-wam-inbound-identity/`  
- await `message_received` before prompt admission  
- propagate `messageId` (+ accountId/senderId) into agent hook context  

---

## Environment (after rebuild)

```bash
OPENCLAW_VERSION=2026.7.1-2
OPENCLAW_WAM_CORE_PATCH=inbound-identity-await-mr-2026.7.1-2
WAM_ATTACHMENT_MCP_ENTRY=/absolute/path/to/wam-apps-ai-mcp/dist/index.js
WAM_ATTACHMENT_ROOTS="…/media/inbound:…/workspaces/bonface-owner/media/inbound"
```

Adapter **refuses to register** if `OPENCLAW_WAM_CORE_PATCH` is missing/mismatched.

---

## Install (when authorized)

1. Apply OpenClaw source patch; rebuild; install Gateway binary.  
2. `npm pack` adapter `0.1.4`; `openclaw plugins install npm-pack:./wam-openclaw-attachment-adapter-0.1.4.tgz --force`  
3. Restart gateway.  
4. Synthetic proof: file → instruction → single prompt → wrappers; delayed file prompt must not claim.

---

## Rollback

1. Unset `OPENCLAW_WAM_CORE_PATCH` (adapter fail-closed).  
2. Reinstall stock OpenClaw `2026.7.1-2` from npm.  
3. Uninstall `wam-attachment-adapter` if desired.  
4. `sudo systemctl restart openclaw-gateway`

---

## Restart behavior

Process-local capability store; restart clears pending/claimed.
