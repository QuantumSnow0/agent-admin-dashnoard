# WAM OpenClaw Attachment Adapter — Install & Rollback Runbook

**Adapter:** `wam-openclaw-attachment-adapter` **v0.1.5**
**OpenClaw:** **2026.7.1-2** + core patch `inbound-identity-await-mr-2026.7.1-2`
**MCP:** **v0.1.18+** (unchanged)

**Plugin-only on stock OpenClaw: NO-GO.** Do not deploy v0.1.2 / v0.1.3 / v0.1.4 / v0.1.5 without the core patch.

---

## Migration / change matrix

| Component | This pass |
|---|---|
| MCP v0.1.18 | **UNCHANGED** |
| Phase 1A.8 SQL / JSONB / reconcile / SMS | **UNCHANGED** |
| OpenClaw core | **REQUIRED source patch** (not dist) |
| Attachment adapter | **0.1.4 → 0.1.5** |

v0.1.5 adds abort/generation safety: timed-out or stale `message_received` handlers
cannot mutate attachment state after prompt admission. File SHA-256 is deferred to
the first wrapper tool invocation (not in the awaited hook path). Registration also
verifies the installed OpenClaw package contains the patch marker file (env alone
is not enough).

---

## Why core patch is required

Live sequence: file `message_received` → instruction `message_received` → **one**
`before_prompt_build` without `messageId`. Plugin cannot tell a delayed file prompt
from the instruction prompt. Proof: `patches/PLUGIN-ONLY-NO-GO.md`.

Patch: `patches/openclaw-2026.7.1-2-wam-inbound-identity/`
Review artifact: `docs/openclaw-2026.7.1-2-wam-inbound-identity-patch-review.tar.gz`

- await `message_received` before prompt admission (bounded ≤ 2000 ms, fail-open)
- hard cap: registration `timeoutMs` cannot exceed 2000 ms for `message_received`
- abort/generation mechanism prevents stale handlers from mutating state post-timeout
- propagate `messageId` (+ accountId/senderId) into agent hook context
- ship marker file `patches/wam-inbound-identity-await-mr-2026.7.1-2.marker`

Full install/rollback steps for the core patch are in the review package
`INSTALL-RUNBOOK.md`.

---

## Environment (after rebuild)

```bash
OPENCLAW_VERSION=2026.7.1-2
OPENCLAW_WAM_CORE_PATCH=inbound-identity-await-mr-2026.7.1-2
WAM_ATTACHMENT_MCP_ENTRY=/absolute/path/to/wam-apps-ai-mcp/dist/index.js
WAM_ATTACHMENT_ROOTS="…/media/inbound:…/workspaces/bonface-owner/media/inbound"
```

Adapter **refuses to register** if `OPENCLAW_WAM_CORE_PATCH` is missing/mismatched
**or** if the installed OpenClaw package lacks the patch marker /
`MESSAGE_RECEIVED_MAX_TIMEOUT_MS` in compiled dist.

---

## Artifacts (review only — not deployed by this pass)

| Artifact | Role |
|---|---|
| `docs/openclaw-2026.7.1-2-wam-inbound-identity-patch-review.tar.gz` | Core patch review package |
| `docs/openclaw-2026.7.1-2-wam-inbound-identity-patch-review.tar.gz.sha256` | Sidecar |
| `docs/openclaw-2026.7.1-2-wam-inbound-identity-patched.tgz` | Installable patched OpenClaw from verified `pnpm build` + `npm pack` |
| `docs/openclaw-2026.7.1-2-wam-inbound-identity-patched.tgz.sha256` | Sidecar |
| `docs/wam-openclaw-attachment-adapter-0.1.5.tgz` | Adapter npm pack |
| `docs/wam-openclaw-attachment-adapter-0.1.5.tgz.sha256` | Sidecar |
| `docs/wam-openclaw-attachment-adapter-0.1.5-review-source.tar.gz` | Adapter review source |
| `docs/wam-openclaw-attachment-adapter-0.1.5-review-source.tar.gz.sha256` | Sidecar |

---

## VPS facts

- OpenClaw installed under: `/home/bonface/.npm-global`
- Current package path: `/home/bonface/.npm-global/lib/node_modules/openclaw`
- Gateway: systemd **user** service
- Service file: `/home/bonface/.config/systemd/user/openclaw-gateway.service`
- npm prefix: bonface npm prefix — use `npm install -g` **without** `sudo`

---

## Install (when authorized)

Use explicit variables so backup and rollback refer to the **same** timestamped tree:

```bash
ts=$(date +%Y%m%d-%H%M%S)
backup_dir=/home/bonface/wam-ai-validation/backups/$ts
current_openclaw=/home/bonface/.npm-global/lib/node_modules/openclaw
mkdir -p "$backup_dir"
```

1. Stop gateway:
   ```bash
   systemctl --user stop openclaw-gateway.service
   ```

2. Backup current OpenClaw:
   ```bash
   cp -a "$current_openclaw" "$backup_dir/openclaw"
   printf '%s\n' "$backup_dir" > "$backup_dir/BACKUP_DIR.txt"
   openclaw --version > "$backup_dir/version-before.txt" || true
   test -d "$backup_dir/openclaw" && test -f "$backup_dir/openclaw/package.json"
   ```

3. Install patched OpenClaw from the verified review artifact (exact pack command
   documented in the core review `INSTALL-RUNBOOK.md`):
   ```bash
   npm install -g ./openclaw-2026.7.1-2-wam-inbound-identity-patched.tgz
   ```

4. Verify patch in **installed code** (not only env):
   ```bash
   test -f "$current_openclaw/patches/wam-inbound-identity-await-mr-2026.7.1-2.marker"
   grep -R "MESSAGE_RECEIVED_MAX_TIMEOUT_MS" "$current_openclaw/dist" | head
   export OPENCLAW_WAM_CORE_PATCH=inbound-identity-await-mr-2026.7.1-2
   export OPENCLAW_VERSION=2026.7.1-2
   ```

5. Install adapter:
   ```bash
   openclaw plugins install npm-pack:./wam-openclaw-attachment-adapter-0.1.5.tgz --force
   ```

6. Start gateway:
   ```bash
   systemctl --user start openclaw-gateway.service
   systemctl --user status openclaw-gateway.service
   journalctl --user -u openclaw-gateway.service -n 50
   ```

7. Synthetic proof: file → instruction → single prompt → wrappers; delayed file
   prompt must not claim.

---

## Rollback

Restore the **same** `$backup_dir` recorded at install time:

```bash
# If shell was restarted, re-load the recorded path:
backup_dir=$(cat /home/bonface/wam-ai-validation/backups/<ts>/BACKUP_DIR.txt)
# or set explicitly, e.g.:
# backup_dir=/home/bonface/wam-ai-validation/backups/20260907-154500
current_openclaw=/home/bonface/.npm-global/lib/node_modules/openclaw
```

1. Stop gateway:
   ```bash
   systemctl --user stop openclaw-gateway.service
   ```

2. Verify backup before restore:
   ```bash
   test -d "$backup_dir/openclaw"
   test -f "$backup_dir/openclaw/package.json"
   cat "$backup_dir/version-before.txt"
   ```

3. Restore OpenClaw from that backup:
   ```bash
   rm -rf "$current_openclaw"
   cp -a "$backup_dir/openclaw" "$current_openclaw"
   # Or reinstall stock from npm:
   # npm install -g openclaw@2026.7.1-2
   ```

4. Unset patch env (adapter fails closed if env is set without code marker):
   ```bash
   unset OPENCLAW_WAM_CORE_PATCH
   ```

5. Uninstall adapter if desired:
   ```bash
   openclaw plugins uninstall wam-attachment-adapter
   ```

6. Start gateway:
   ```bash
   systemctl --user start openclaw-gateway.service
   journalctl --user -u openclaw-gateway.service -n 30
   ```

---

## Restart behavior

Process-local capability store; restart clears pending/claimed.
